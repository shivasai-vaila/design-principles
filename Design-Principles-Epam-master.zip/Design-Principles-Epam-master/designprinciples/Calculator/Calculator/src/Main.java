public class Main {

    public static void main(String[] args) {
        UI calculatorUI = new UI();
        calculatorUI.setVisible(true);
        calculatorUI.setSize(800, 800);
    }
}